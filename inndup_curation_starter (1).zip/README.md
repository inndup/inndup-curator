# INNDUP — Sistema de Curación de Información (MVP)

Este repositorio es un **arranque técnico** para construir el motor de curación de INNDUP
y exponerlo como **API** que luego alimenta la plataforma digital (Nexus Innova).

## ⚙️ Stack
- Python 3.11
- FastAPI (API REST)
- SQLModel + SQLite (persistencia ligera; puedes migrar a Postgres/pgvector)
- httpx + BeautifulSoup4 (ingesta web básica)
- scikit-learn (deduplicación/TF‑IDF)
- faiss-cpu (búsqueda semántica local). Alternativa: Postgres + pgvector.
- python-dotenv (config)
- tiktoken / openai (opcional: embeddings/chat para clasificación enriquecida)

## 🚀 Ejecutar local
```bash
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
API en: http://127.0.0.1:8000/docs

## 🧠 Flujo del Motor de Curación
1) **Ingesta** → descarga/scrapea fuentes, normaliza campos.
2) **Limpieza & Enriquecimiento** → dedup, extracción de entidades, categorías.
3) **Scoring** → relevancia por país/sector/tema (ponderaciones).
4) **Indexación** → índice semántico FAISS (+ filtros por metadatos).
5) **Serving** → endpoints `/search`, `/recommend`, `/items/{id}`.

## 🔑 Variables de entorno (.env)
```
OPENAI_API_KEY=sk-...             # opcional (para embeddings o clasificación con LLM)
CURATION_DEFAULT_COUNTRIES=CO,MX,US
CURATION_DEFAULT_SECTORS=fintech,healthtech,edtech,cleantech
```
> Si no configuras `OPENAI_API_KEY`, el sistema usa **TF-IDF** para embeddings básicos.

## 🧪 Probar rápido
1. Coloca URLs o texto en `tests/sample_sources.json`.
2. Llama a `/ingest/run` (POST) para procesar y crear el índice.
3. Consulta `/search?q=financiamiento` o `/recommend?profile=...`.

## 🧩 Integración con la Plataforma
- Este servicio expone **JSON** que la web puede consumir para módulos:
  - **Portal de Proyectos**, **Mentoría**, **Centro de Recursos**, **Eventos**.
- Añade autenticación (JWT) y rate limiting antes de producción.

## 🛡️ Seguridad y Privacidad
- Sanitización de HTML, normalización, stripping de PII (configurable).
- Logs mínimos; no guardes claves ni PII en texto claro.
- Preparado para CORS/Origins permitidos.
- Lista de **fuentes blancas** y robots.txt respetado por defecto.

## 📦 Escalar
- Migrar a Postgres + pgvector.
- Sustituir FAISS local por servicio vectorial.
- Programar ingestas con Celery/Beat o Airflow.
- Observabilidad: Prometheus + Grafana.
