import numpy as np
import faiss
from typing import List, Tuple
from sklearn.feature_extraction.text import TfidfVectorizer

class SemanticIndex:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(stop_words='spanish', max_features=4096)
        self.index = None
        self.ids = []

    def build(self, docs: List[str], ids: List[int]):
        X = self.vectorizer.fit_transform(docs).astype(np.float32).toarray()
        self.index = faiss.IndexFlatIP(X.shape[1])
        # Normalize for cosine
        faiss.normalize_L2(X)
        self.index.add(X)
        self.ids = ids

    def search(self, query: str, k: int = 10) -> List[int]:
        if self.index is None: return []
        q = self.vectorizer.transform([query]).astype(np.float32).toarray()
        faiss.normalize_L2(q)
        D, I = self.index.search(q, k)
        return [self.ids[i] for i in I[0] if i >= 0]
