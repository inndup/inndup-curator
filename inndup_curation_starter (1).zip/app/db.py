from sqlmodel import SQLModel, Session, create_engine
from pathlib import Path

DB_PATH = Path("data/inndup.db")
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
engine = create_engine(f"sqlite:///{DB_PATH}", echo=False)

def init_db():
    SQLModel.metadata.create_all(engine)

def get_session():
    from contextlib import contextmanager
    @contextmanager
    def _session():
        with Session(engine) as session:
            yield session
    return _session()
