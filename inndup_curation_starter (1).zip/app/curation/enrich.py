from typing import List, Dict
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Heurística rápida de idioma/es/categorías; puedes reemplazar con LLM
TECH_WORDS = ["AI","IA","blockchain","fintech","healthtech","edtech","cloud","datos","dato","biotech","energia","limpia","sostenible","circular"]

def detect_sector(text: str) -> str | None:
    t = text.lower()
    if "fintech" in t: return "fintech"
    if "health" in t or "salud" in t: return "healthtech"
    if "educa" in t: return "edtech"
    if "energ" in t or "sosten" in t or "circular" in t: return "cleantech"
    if "ia" in t or "inteligencia artificial" in t: return "ai"
    return None

def score_item(item: Dict, prefs: dict) -> float:
    score = 0.0
    text = (item.get("title","") + " " + item.get("summary","")).lower()
    # sector
    sec = detect_sector(text) or ""
    if sec in prefs.get("sectors", []):
        score += 0.5
    # países (heurística por mención)
    for c in prefs.get("countries", []):
        if c.lower() in text:
            score += 0.2
    # tecnología/sostenibilidad
    score += sum(0.03 for w in TECH_WORDS if w.lower() in text)
    return min(score, 1.0)

def deduplicate(items: List[Dict]) -> List[Dict]:
    # Deduplicación por hash + similitud TF-IDF sobre títulos
    if not items: return []
    titles = [i["title"] for i in items]
    vec = TfidfVectorizer(stop_words='spanish').fit_transform(titles)
    sims = cosine_similarity(vec)
    keep = []
    used = set()
    for i in range(len(items)):
        if i in used: continue
        used.add(i)
        for j in range(i+1, len(items)):
            if sims[i,j] > 0.9:
                used.add(j)
        keep.append(items[i])
    return keep
