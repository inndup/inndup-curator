import hashlib, re
from bs4 import BeautifulSoup

def clean_html(html: str) -> str:
    try:
        soup = BeautifulSoup(html, 'html.parser')
        # remove scripts/styles
        for t in soup(['script','style']):
            t.decompose()
        text = soup.get_text(" ", strip=True)
    except Exception:
        text = html
    text = re.sub(r"\s+", " ", text).strip()
    return text

def quick_hash(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()[:16]
