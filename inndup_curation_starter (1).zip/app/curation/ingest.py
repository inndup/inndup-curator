import httpx, asyncio, datetime as dt
from typing import List, Dict
from .utils import clean_html, quick_hash

async def fetch_url(client: httpx.AsyncClient, url: str) -> Dict:
    try:
        r = await client.get(url, timeout=20)
        r.raise_for_status()
        content = clean_html(r.text)
        title = url.split('/')[-1][:120] or "sin_titulo"
        return {"url": url, "title": title, "content": content, "summary": content[:500], "published_at": dt.datetime.utcnow().isoformat()}
    except Exception as e:
        return {"url": url, "error": str(e)}

async def ingest_urls(urls: List[str]) -> List[Dict]:
    async with httpx.AsyncClient(follow_redirects=True, headers={"User-Agent":"INNDUP-Curator/1.0"}) as client:
        tasks = [fetch_url(client, u) for u in urls]
        res = await asyncio.gather(*tasks)
        items = [r for r in res if "error" not in r]
        for it in items:
            it["hash"] = quick_hash((it["title"] + it["content"])[:4000])
        return items
