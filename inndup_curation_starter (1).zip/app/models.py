from sqlmodel import SQLModel, Field
from typing import Optional, List
from datetime import datetime

class Item(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    url: Optional[str] = None
    title: str
    summary: str
    content: str
    lang: str = "es"
    source: str = "manual"
    published_at: Optional[datetime] = None
    country: Optional[str] = None
    sector: Optional[str] = None
    tags: Optional[str] = None   # coma-separado
    score: float = 0.0
    hash: str

class IndexState(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    built_at: datetime = Field(default_factory=datetime.utcnow)
    n_items: int = 0
