from fastapi import FastAPI, Query, Body
from fastapi.middleware.cors import CORSMiddleware
from sqlmodel import select
from .db import init_db, get_session
from .models import Item, IndexState
from .config import settings
from .curation.ingest import ingest_urls
from .curation.enrich import deduplicate, detect_sector, score_item
from .search.index import SemanticIndex

app = FastAPI(title="INNDUP Curation API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

init_db()
SEM_INDEX = SemanticIndex()

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/ingest/run")
async def run_ingest(payload: dict = Body(...)):
    urls = payload.get("urls", [])
    prefs = {
        "countries": payload.get("countries", settings.countries),
        "sectors": payload.get("sectors", settings.sectors),
    }
    items = await ingest_urls(urls)
    # Enriquecimiento
    for it in items:
        it["sector"] = detect_sector(it["content"])
        it["score"] = score_item(it, prefs)
    items = deduplicate(items)

    # Persistencia
    from .db import engine
    from sqlmodel import Session
    objs = []
    with Session(engine) as s:
        for it in items:
            obj = Item(
                url=it.get("url"),
                title=it["title"],
                summary=it.get("summary","")[:1000],
                content=it.get("content","")[:8000],
                source="web",
                country=None,
                sector=it.get("sector"),
                tags=None,
                score=it.get("score",0.0),
                hash=it["hash"],
            )
            s.add(obj)
            objs.append(obj)
        s.commit()
        for o in objs: s.refresh(o)

        # Reindexar
        res = s.exec(select(Item)).all()
        docs = [f"{r.title}. {r.summary}" for r in res]
        ids = [r.id for r in res]
        SEM_INDEX.build(docs, ids)
        state = IndexState(n_items=len(ids))
        s.add(state); s.commit()

    return {"ingested": len(objs)}

@app.get("/search")
def search(q: str = Query(...), k: int = 10):
    ids = SEM_INDEX.search(q, k=k)
    from .db import engine
    from sqlmodel import Session
    with Session(engine) as s:
        results = [s.get(Item, i) for i in ids]
    return {"results": [r.model_dump() for r in results if r]}

@app.get("/items/{item_id}")
def get_item(item_id: int):
    from .db import engine
    from sqlmodel import Session
    with Session(engine) as s:
        it = s.get(Item, item_id)
        return it

@app.get("/recommend")
def recommend(profile: str = Query("emprendimiento sostenible latinoamérica")):
    # Por ahora, recomendar = búsqueda semántica del perfil
    ids = SEM_INDEX.search(profile, k=10)
    from .db import engine
    from sqlmodel import Session
    with Session(engine) as s:
        results = [s.get(Item, i) for i in ids]
    return {"profile": profile, "results": [r.model_dump() for r in results if r]}
