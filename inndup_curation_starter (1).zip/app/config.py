from pydantic import BaseModel
from dotenv import load_dotenv
import os

load_dotenv()

class Settings(BaseModel):
    openai_api_key: str | None = os.getenv("OPENAI_API_KEY")
    countries: list[str] = (os.getenv("CURATION_DEFAULT_COUNTRIES","CO,MX,US")).split(",")
    sectors: list[str] = (os.getenv("CURATION_DEFAULT_SECTORS","fintech,healthtech,edtech,cleantech")).split(",")
    allowed_origins: list[str] = (os.getenv("ALLOWED_ORIGINS","*")).split(",")

settings = Settings()
